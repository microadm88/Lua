local a,b

if a >= 0 then
  if b >= 0 then
    b = 1
  else
    b = 2
  end
end