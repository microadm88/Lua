local a,b,c;
repeat
	repeat
		a = a+1
	until a > 4
	a=a+3
until a > 5