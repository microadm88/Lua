local tb1={
{f="i",t="dwID"},
{f="i",t="dwID"},
{f="i",t="dwID"},
{f="i",t="dwID"},
{f="i",t="dwID"},

{f="i",t="dwID"},
{f="i",t="dwID"},
{f="i",t="dwID"},
{f="i",t="dwID"},
{f="i",t="dwID"},

{f="i",t="dwID"},
{f="i",t="dwID"},
{f="i",t="dwID"},
{f="i",t="dwID"},
{f="i",t="dwID"},

{f="i",t="dwID"},
{f="i",t="dwID"},
{f="i",t="dwID"},
{f="i",t="dwID"},
{f="i",t="dwID"},

{f="s",t="szScriptName"},
{f="s",t="szScriptName"},
{f="s",t="szScriptName"},--R3-R25
y={f="s",t="szScriptName"},
x=3,
a={f="s",t="szScriptName"},
b={f="s",t="szScriptName"},
["123"]=123,
[123]=456,

}

print(tb1["123"])
print(tb1[123])