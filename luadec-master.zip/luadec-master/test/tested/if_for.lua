if k<3 then
	for k,v in pairs(xx) do
		print(k+2)
	end
else
	for k,v in pairs(xx) do
		print(v+2)
	end
end
--print(k,v)

