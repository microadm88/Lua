for k,v in pairs(xx) do
	if k<3 then
		print(k+2)
	else
		print(v+4)
	end
	--print(k,v)
end
