local function x()
	if a then
	else
		if b then
			c=0
		end
	end
end

local function x()
	if not a then
		if b then
			c=0
		end
	end
end