if a then
else
	if b then
		c=0
	end
end
--[[
-- Decompiled using luadec 2.2 GBK R5bf00c7
if a then

  -- DECOMPILER ERROR: 2 unprocessed JMP targets
end
--]]
