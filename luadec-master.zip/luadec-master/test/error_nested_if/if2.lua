if a == b then
  print(a)
  if c then
	print(c)
  end
else
  local hnd = d
  if hnd then
	print(d)
  end
end