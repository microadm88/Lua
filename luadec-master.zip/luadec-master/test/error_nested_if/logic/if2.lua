local a,b,c
local p1,p2,p3,p4

--1100
if a then
	if b then
		p1()
	else
		p2()
	end
end
