for k,v in pairs(a) do
	print(k,v)
end
