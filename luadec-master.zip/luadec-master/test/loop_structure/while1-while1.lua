local a,b,c,f

while 1 do
	f(a)
end

while 1 do
	f(b)
end