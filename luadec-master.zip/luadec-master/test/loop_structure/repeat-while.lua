local a,b,c

repeat
	while (a > 0 or b>0) and c>0  do
		if a+b>0 then
			break;
		end
	end
until a>0