local a,b,c,f

while 1 do
  f(b)
  if c then
    f(a)
  end
end