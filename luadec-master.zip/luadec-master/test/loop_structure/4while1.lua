local a,b,c,d,e,f,g

while 1 do
	a()
	
	while 1 do
		b()
	end
	
	f()
	
	while 1 do
		c()
		while 1 do
			d()
		end
		e()
	end
	
	g()
end