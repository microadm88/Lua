local a
while 1 do
	a()
end