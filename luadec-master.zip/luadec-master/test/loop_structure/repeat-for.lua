local a,b,c
repeat
	for i = 1, 10 do
		print(i)
	end
until a>0