local a,b,c,f

while 1 do
  repeat
    f(b)
  until c
  f(a)
end