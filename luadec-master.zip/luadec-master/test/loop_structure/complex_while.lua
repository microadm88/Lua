local a,b,c
while (a > 0 or b>0) and c>0 do
	print(a)
	if a+b > 0 then
		break
	end
	print(b)
end
