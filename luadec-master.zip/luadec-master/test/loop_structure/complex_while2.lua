local a,b,c
while (a > 0 or b>0) and c>0 do
	print(a)
	break;
end