local a
while a > 0 do
	print(a)
end
