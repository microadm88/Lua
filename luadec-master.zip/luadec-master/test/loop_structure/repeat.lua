local a
repeat
	print(a)
until a > 0