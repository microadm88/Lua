local a, b
while a > 0 do
	print(a)
	while b > 0 do
		print(b)
	end
end
