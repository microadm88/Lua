local a
repeat
	a()
until false
