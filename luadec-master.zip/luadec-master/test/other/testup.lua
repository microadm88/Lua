local cc, dd=3,4
print(cc+dd)
local a=3
local b=4

function c()
	local c = a+b
	return c
end