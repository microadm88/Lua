  for v = 8,18,1 do
	print(v)
  end