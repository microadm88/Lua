local a=print
local b={...}

local c={1}