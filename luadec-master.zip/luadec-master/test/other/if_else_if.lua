local a,b,c,d,e
local print = print
if a then
	print(a)
elseif b then
	print(b)
elseif c then
	print(c)
end

xxx()