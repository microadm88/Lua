local a,b
b = (a ~= 0)