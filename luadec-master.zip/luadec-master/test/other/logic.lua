local a,b,c,d,e,f,g

local a = b>c
local d = (e==f)

--local d = (a and b ) or (not c)