
assert(-(1 or 2) == -1 and (1 and 2)+(-1.25 or -4) == 0.75);
