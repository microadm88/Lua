function a(b,c,d)
	if b>3 then
		c = 4
	else
		c = 5
	end
	print(c)
end