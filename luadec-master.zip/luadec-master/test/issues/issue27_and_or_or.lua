-- Command line: -fc -fn 0_10 E:\cbprojects\luadec\angrybirds_lua\scripts\menus\level_end.lua 

Decompiled_0_10 = function (p)
	local a,b,c,d
	if ((a and b) or c or d) then
		p = 3
	end
end
