local a, b

function f()
	a,b=nil
	return false
end;
