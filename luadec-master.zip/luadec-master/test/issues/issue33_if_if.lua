local a,b,c,d,e

if a then
	b()
	if c then
		d()
	end
end
e()
