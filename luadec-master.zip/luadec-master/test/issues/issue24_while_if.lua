local a,b;

while a and b do
  f()
end

while a do
  if b then
    f()
  end
end

while a do
  while b do
    f()
  end
end