local a, b, c

repeat
  repeat
    print(a)
  until b > 0
  print(c)
until a>0

print(c)