local function a1()
	local a,b,c
	while 1 do
		repeat
			print(a)
		until c > 0
		print(b)
	end
end