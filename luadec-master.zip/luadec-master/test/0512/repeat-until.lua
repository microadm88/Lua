local a,b
repeat
	if a>0 then
		break
	end
	print(a)
until b<0