local a,b,c

--while a > 0 do
	print(a)
	if b > 0 then
		print(c)
		--break
	end
--end

print(c)