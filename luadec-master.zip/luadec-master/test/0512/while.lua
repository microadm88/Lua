local a,b,c

while a > 0 do
	while b > 2 do
		c=c+1 --print(b)
	end
	while b <= 2 do
		c=c-1 --print(c)
	end
end
return a

