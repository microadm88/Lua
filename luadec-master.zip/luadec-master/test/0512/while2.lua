local a,b,c

repeat
	print(a)
	if b > 0 then
		print(c)
		--break
	end
until a>0

print(c)