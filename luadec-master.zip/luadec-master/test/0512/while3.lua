local a,b,c

while a > 0 and b > 0 do
	print(c)
end
