local function a1()
	local a,b,c
	while 1 do
		print(a)
		if c > 0 then
			break
		end
	end
end

local function a2()
	local a,b,c
	while a > 0 do
		print(a)
		if c > 0 then
			break
		end
	end
end