local a,b,c

repeat
	for i = 1,100,5 do 
		a = a + i
	end
until false