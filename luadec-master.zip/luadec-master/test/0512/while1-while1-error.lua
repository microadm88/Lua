local a, b, c = nil, nil, nil
repeat
  repeat
    repeat
      print(a)
    until c > 0
    do break end
  until false
  c = a + b
until false