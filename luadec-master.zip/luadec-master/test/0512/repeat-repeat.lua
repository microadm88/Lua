local a, b, c = nil, nil, nil
repeat
  repeat
    repeat
      print(a)
    until a > 0
    do break end
  until b > 0
  c = a + b
until d > 0