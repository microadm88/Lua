local a,b,c
while 1 do
	while 1 do
		print(a)
		if c > 0 then
			break
		end
	end
	c = a + b
end