if buffer then
  print("buffer")
end
local x = {table_elt = 6}
local list = {1,
              6,
              3,
              2,
              6,
              3,
              2,
              6,
              6}
