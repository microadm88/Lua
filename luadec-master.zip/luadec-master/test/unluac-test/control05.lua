for i = 1, 10 do
  local x = f()
  if a then
    local y = g()
      if b then
        print(b)
      end
    break
  end
end