if a then
  local x = 3
  if b then
    print(a, b)
  end
end