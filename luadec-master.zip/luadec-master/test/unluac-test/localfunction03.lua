local function factorial(n)
  return "not recursive"
end
print(factorial(10))
