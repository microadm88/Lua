local a
a = d and e and f and a and g and h and i
a = d or e or f or a or g or h or i
