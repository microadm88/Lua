for item in iter() do
  if complicated_condition() then
    f()
	if additional() then
	  g()
	end
	break
  end
end