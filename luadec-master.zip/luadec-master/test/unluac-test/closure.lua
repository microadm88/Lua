f = function(a, b)
  local c = a + b
  return c ^ 2
end
print(f(3, 4))
