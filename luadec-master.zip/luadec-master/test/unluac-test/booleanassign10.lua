local x
if x == nil then
  x = (not y) or (z == w)
end
print(x)