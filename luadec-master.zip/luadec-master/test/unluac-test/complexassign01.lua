if buffer then
  print("hello")
end
local single1 = 1
local single2 = 2
local single3 = 3
if buffer then
  print("hello")
end
local single4 = 4
local single5 = 5
local single6 = 6
