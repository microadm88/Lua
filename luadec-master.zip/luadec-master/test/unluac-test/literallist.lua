x = {1,
     2,
     7,
     "frog",
     z,
     y * w,
     99}
