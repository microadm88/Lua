print(a and b, a or b)
