print("begin")
local x, y, z