local a
a = b or c or d == e
