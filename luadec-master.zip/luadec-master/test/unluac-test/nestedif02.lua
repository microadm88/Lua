if a then
  print(a)
  if b then
    print(b)
    if c then
      print(c)
    else
      print(z)
    end
  else
    print(y)
  end
else
  print(x)
end