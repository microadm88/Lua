if x then
  do return end
  print(x)
end