if a < 2 then
  print("a < 2")
end
if 2 > a then
  print("2 > a")
end
