local factorial = function(n)
  return "not recursive"
end
print(factorial(10))
