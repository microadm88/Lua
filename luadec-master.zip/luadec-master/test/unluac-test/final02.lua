while x > 0 do
  do break end
  print(x)
  x = x - 1
end