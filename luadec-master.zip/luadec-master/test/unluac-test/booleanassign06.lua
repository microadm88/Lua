if not thing.a and not thing.b then
  local value = "default"
end