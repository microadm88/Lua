while a do
  f()
end
while a do
  if b then
    f()
  end
end
while a do
  while b do
    f()
  end
  g()
end
while a do
  f()
  while b do
    g()
  end
end
