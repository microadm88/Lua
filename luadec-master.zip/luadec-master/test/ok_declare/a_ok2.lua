local a
print()
a=234