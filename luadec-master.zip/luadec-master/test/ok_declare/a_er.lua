local a
a=234