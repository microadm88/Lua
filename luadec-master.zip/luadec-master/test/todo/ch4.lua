local a,b,c,d,e

if a then
 if not b or c then
  e=102
 end
else
 if d then
  e=102
 end
end