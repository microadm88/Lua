local a,b,c,d,e,f,g

if a then
	print(a)
elseif f(b) then
	print(b)
elseif c then
	print(c)
end
