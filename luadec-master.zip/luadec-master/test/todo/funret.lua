local a,b,f
a,b = f()
c,d = f()