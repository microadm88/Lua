local a,b

while 1 do
	if a then
		print(a)
	end
	print(b)
end
