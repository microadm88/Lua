if a then
	while 1 do
		f1()
		break
	end
end

f()

if a then
	f1()
else
	while 1 do
		f2()
		break
	end
end

f()

