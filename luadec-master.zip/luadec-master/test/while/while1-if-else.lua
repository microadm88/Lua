local a,b,c

while 1 do
	if a then
		print(a)
	else
		print(b)
	end
	print(c)
end