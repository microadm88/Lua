local a,b,c

while 1 do
	local d,e
	print(c)
end