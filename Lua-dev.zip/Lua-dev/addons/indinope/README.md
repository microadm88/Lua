# IndiNope 1.0.4
Hides visual effects from geomancy on players.

Currently does not hide geomancy effect around luopans.

**No commands.** Load it and it's on, unload and it's off.

### Changelog:

1.0.4 - More tweaks.  
1.0.3 - A few tweaks.  
1.0.1 - Fixed a bug where Indi-Nope would make Master stars disappear. Thanks Kenshi for finding out.  
1.0.0 - Initial release.  

Thanks to Thorny, this addon is a port to windower of his Ashita code with the same functionality.
