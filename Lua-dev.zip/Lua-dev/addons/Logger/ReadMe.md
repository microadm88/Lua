# Logger

Outputs all text that appears in the chat log into a text file under `Windower/logs/`.
