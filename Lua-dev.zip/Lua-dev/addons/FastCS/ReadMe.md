**Author:**  Cairthenn<br>
**Version:**  1.2<br>
**Date:** Jan. 31, 2016<br>

# FastCS #

* Uses the config plugin to automatically disable the frame rate cap during custcenes.
* Note that this affects regular NPC interaction menus.
* You must have the config plugin loaded.
* This may cause undesirable behavior during specific cutscenes. Unload the addon if this happens.
