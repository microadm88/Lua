**Author:** Ricky Gall
**Version:** v 1.07
**Description:**  
Addon is to allow you to ignore people in ffochat.

**Abbreviation:** //cblock

**Commands:**

1. //cblock delete &lt;name&gt; --Unignores &lt;name&gt; so you can see what they're saying again
2. //cblock ignore &lt;name&gt; --Ignores &lt;name&gt; adds then to your blacklist.txt so you don't see anything from them until you either remove them or delete blacklist.txt.
