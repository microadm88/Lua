Author: Krizz

Version: .5

Date: 20130601

Salvage2

Abbreviation: //s2

Commands:
* help - Shows a menu of commands in game
* pos <x> <y> - Positions the pathos remaining box. Default location is 1000,250.
* [hide/show] - Toggle display of the pathos remaining box.
* timer [start/stop] - Will start or stop the 100 minute zone timer.
* remove <pathos> - Removes the pathos from the list.

To do:
* Change zone comparison to use zone IDs.

Known Issues:
* May not always display the box upon zoning in until a pathos is removed.

