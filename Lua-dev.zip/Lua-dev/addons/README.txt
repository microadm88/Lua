Lua addons are similar to Windower Plugins, in that they are loaded once and continue to remain active, acting upon events and commands.

You can load Lua addons via the //lua load command, similar to plugins.  For example, if you had an addon named test.lua, you would load it by typing:
//lua load test 
or
//lua l test

