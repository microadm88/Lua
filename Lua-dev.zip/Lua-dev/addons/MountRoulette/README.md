# Final Fantasy XI Mount Roulette

A Lua addon to summon a mount at random for Windower 4. Mimics the FFXIV Mount Roulette function.

## Usage

Get the addon from the addon section of the Windower launcher.

### Summon a mount

`//mr`

This will also dismount you if you're currently mounted.

## Mount music

In an earlier version, this addon disabled mount music. This is now removed in favour of the MountMuzzle addon.
