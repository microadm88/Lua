Mote-libs
=========

These are the Mote-Include library files for GearSwap.

Please see https://github.com/Kinematics/GearSwap-Jobs/wiki for documentation.
