# Dimmer
## English
- Automatically choose and uses the first Dimensional Ring on cool down to warp to Reisenjima for you.

### Command
- `//dim` OR `//dimmer`
- `//dim all` OR `//dimmer all` will use ring on all characters.
- Priorities are:
    1. Dim. Ring (Holla)
    2. Dim. Ring (Dem)
    3. Dim. Ring (Mea)
    
## 日本語
- Should support the Japanesse client too.