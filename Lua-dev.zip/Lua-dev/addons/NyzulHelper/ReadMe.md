**Authors:** Glarin
**Version:** 1.0
**Date:** 7/14/2020

**Description:**
NyzulHelper is an addon that tracks and displays the Current Floor, Time Remaining, Objective, Floors Completed, Reward Rate, and Potenial Tokens.