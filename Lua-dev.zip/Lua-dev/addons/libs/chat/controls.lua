return {
    color1 =      string.char(0x1F),
    color2 =      string.char(0x1E),
    reset =       string.char(0x1E, 0x01),
}
