Shared libraries go here. These can be referenced from any script or addon.
