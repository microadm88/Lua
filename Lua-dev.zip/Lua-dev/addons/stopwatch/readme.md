**Commands:**

sw start
    to start the stopwatch
  
sw stop
    to pause the stopwatch
    
sw reset
    to reset the stopwatch cumulative time to 0
    
    
Addon by Patrick Finnigan (Puhfyn@Ragnarok) - https://github.com/finnigantime.
