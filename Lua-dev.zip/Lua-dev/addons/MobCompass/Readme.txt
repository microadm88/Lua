Author: Sebastien Gomez
Version: 1.1

--------------------------
Multiple compasses in one. 
--------------------------
Compass arrows indicate position relative to the targeted monster.
Compass readout displays position relative to the direction the targeted monster is facing.