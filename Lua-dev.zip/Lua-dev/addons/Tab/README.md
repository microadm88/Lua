# Tab

### English
- Simple addon Replace Tab key input to `<stnpc>` or `<stpc>`. (X+Tab)
- **Tips:** if you won't to include pet or trust in `<stnpc>` by other players, use `/ignorepet on` and `/ignoretrust on` (in-game commands)

### 日本語
- Tabキーの動作を`<stnpc>`または`<stpc>`(X+Tab)に置き換えます。
- **Tips:** `<stnpc>`に他プレイヤーのペットやフェイスを含めたくない場合、`/ignorepet on` または `/ignorefaith on`（ゲーム内コマンド）をご利用ください。
