# SpeedChecker

Displays a small box indicating your current movement speed modifier (+/- X%).
