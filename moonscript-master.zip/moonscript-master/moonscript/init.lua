do
  local _with_0 = require("moonscript.base")
  _with_0.insert_loader()
  return _with_0
end
