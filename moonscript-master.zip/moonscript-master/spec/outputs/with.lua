do
  local a
  a = function()
    do
      local _with_0 = something
      print(_with_0.hello)
      print(hi)
      print("world")
      return _with_0
    end
  end
end
do
  do
    local _with_0 = leaf
    _with_0.world()
    _with_0.world(1, 2, 3)
    local g = _with_0.what.is.this
    _with_0.hi(1, 2, 3)
    _with_0:hi(1, 2).world(2323)
    _with_0:hi("yeah", "man")
    _with_0.world = 200
  end
end
do
  local zyzyzy
  do
    local _with_0 = something
    _with_0.set_state("hello world")
    zyzyzy = _with_0
  end
end
do
  local x = 5 + (function()
    do
      local _with_0 = Something()
      _with_0:write("hello world")
      return _with_0
    end
  end)()
end
do
  local x = {
    hello = (function()
      do
        local _with_0 = yeah
        _with_0:okay()
        return _with_0
      end
    end)()
  }
end
do
  do
    local _with_0 = foo
    local _ = _with_0:prop("something").hello
    _with_0.prop:send(one)
    _with_0.prop:send(one)
  end
end
do
  do
    local _with_0 = a, b
    print(_with_0.world)
  end
  local mod
  do
    local _M = { }
    _M.Thing = "hi"
    mod = _M
  end
  do
    local a, b = something, pooh
    print(a.world)
  end
  local x
  do
    local a, b = 1, 2
    print(a + b)
    x = a
  end
  print((function()
    do
      local a, b = 1, 2
      print(a + b)
      return a
    end
  end)())
  local p
  do
    local _with_0 = 1
    hello().x, world().y = _with_0, 2
    print(a + b)
    p = _with_0
  end
end
do
  local x = "hello"
  do
    x:upper()
  end
end
do
  do
    local k = "jo"
    print(k:upper())
  end
end
do
  do
    local a, b, c = "", "", ""
    print(a:upper())
  end
end
do
  local a = "bunk"
  do
    local b, c
    a, b, c = "", "", ""
    print(a:upper())
  end
end
do
  do
    local _with_0 = j
    print(_with_0:upper())
  end
end
do
  do
    local _with_0 = "jo"
    k.j = _with_0
    print(_with_0:upper())
  end
end
do
  do
    local _with_0 = a
    print(_with_0.b)
    do
      local _with_1 = _with_0.c
      print(_with_1.d)
    end
  end
end
do
  do
    local _with_0 = a
    do
      local _with_1 = 2
      _with_0.b = _with_1
      print(_with_1.c)
    end
  end
end
do
  local _
  _ = function()
    do
      local _with_0 = hi
      return _with_0.a, _with_0.b
    end
  end
end
do
  do
    local _with_0 = dad
    _with_0["if"]("yes")
    local y = _with_0["end"].of["function"]
    return _with_0
  end
end