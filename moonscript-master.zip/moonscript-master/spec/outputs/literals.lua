local _ = 121
_ = 121.2323
_ = 121.2323e-1
_ = 121.2323e13434
_ = 2323E34
_ = 0x12323
_ = 0xfF2323
_ = 0xabcdef
_ = 0xABCDEF
_ = .2323
_ = .2323e-1
_ = .2323e13434
_ = 1LL
_ = 1ULL
_ = 9332LL
_ = 9332
_ = 0x2aLL
_ = 0x2aULL
_ = [[ hello world ]]
_ = [=[ hello world ]=]
_ = [====[ hello world ]====]
_ = "another world"
_ = 'what world'
_ = "\nhello world\n"
_ = 'yeah\nwhat is going on\nhere is something cool'
return nil