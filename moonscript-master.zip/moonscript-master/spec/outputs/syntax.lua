local a = 1 + 2 * 3 / 6
local bunch, go, here
a, bunch, go, here = another, world
func(arg1, arg2, another, arg3)
local we
here, we = function() end, yeah
local the, different
the, different = function()
  return approach
end, yeah
dad()
dad(lord)
hello(one, two)();
(5 + 5)(world)
fun(a)(b)
fun(a)(b)
fun(a)(b, bad(hello))
hello(world(what(are(you(doing(here))))))
what(the)[3243](world, yeck(heck))
hairy[hands][are](gross)(okay(okay[world]))
local _ = (get[something] + 5)[years]
local i, x = 200, 300
local yeah = (1 + 5) * 3
yeah = ((1 + 5) * 3) / 2
yeah = ((1 + 5) * 3) / 2 + i % 100
local whoa = (1 + 2) * (3 + 4) * (4 + 5)
_ = function()
  if something then
    return 1, 2, 4
  end
  return print("hello")
end
_ = function()
  if hello then
    return "heloo", "world"
  else
    return no, way
  end
end
_ = function()
  return 1, 2, 34
end
return 5 + function()
  return 4 + 2
end
return 5 + (function()
  return 4
end) + 2
print(5 + function()
  _ = 34
  return good(nads)
end)
something('else', "ya")
something('else')
something("else")
_ = something([[hey]]) * 2
_ = something([======[hey]======]) * 2
_ = something('else'), 2
_ = something("else"), 2
_ = something([[else]]), 2
something('else', 2)
something("else", 2)
something([[else]], 2)
_ = here(we)("go")[12123]
local something = {
  test = 12323,
  what = function()
    return print("hello world")
  end
}
print(something.test)
local frick = {
  hello = "world"
}
local argon = {
  num = 100,
  world = function(self)
    print(self.num)
    return {
      something = function()
        return print("hi from something")
      end
    }
  end,
  somethin = function(self, str)
    print("string is", str)
    return {
      world = function(a, b)
        return print("sum", a + b)
      end
    }
  end
}
something.what()
argon:world().something()
argon:somethin("200").world(1, 2)
x = -434
x = -hello(world(one(two)))
local hi = -"herfef"
x = -(function()
  local _accum_0 = { }
  local _len_0 = 1
  for x in x do
    _accum_0[_len_0] = x
    _len_0 = _len_0 + 1
  end
  return _accum_0
end)()
if cool then
  print("hello")
end
if not (cool) then
  print("hello")
end
if not (1212 and 3434) then
  print("hello")
end
for i = 1, 10 do
  print("hello")
end
print("nutjob")
if hello then
  _ = 343
end
if cool then
  print("what")
else
  _ = whack
end
local arg = {
  ...
}
x = function(...)
  return dump({
    ...
  })
end
x = not true
local y = not (5 + 5)
y = #"hello"
x = #{
  #{ },
  #{
    1
  },
  #{
    1,
    2
  }
}
_ = hello, world
something:hello(what)(a, b)
something:hello(what)
something.hello:world(a, b)
something.hello:world(1, 2, 3)(a, b)
x = 1232
x = x + (10 + 3)
local j = j - "hello"
y = y * 2
y = y / 100
local m = m % 2
local hello = hello .. "world"
self.__class.something = self.__class.something + 10
self.something = self.something + 10
local _update_0 = "hello"
a[_update_0] = a[_update_0] + 10
local _update_1 = "hello" .. tostring(tostring(ff))
a[_update_1] = a[_update_1] + 10
local _update_2 = four
a[_update_2].x = a[_update_2].x + 10
x = 0
local _list_0 = values
for _index_0 = 1, #_list_0 do
  local v = _list_0[_index_0]
  _ = ((function()
    if ntype(v) == "fndef" then
      x = x + 1
    end
  end)())
end
hello = {
  something = world,
  ["if"] = "hello",
  ["else"] = 3434,
  ["function"] = "okay",
  good = 230203
}
div({
  class = "cool"
})
_ = 5 + what(wack)
what(whack + 5)
_ = 5 - what(wack)
what(whack - 5)
x = hello - world - something;
(function(something)
  if something == nil then
    do
      local _with_0 = what
      _with_0:cool(100)
      something = _with_0
    end
  end
  return print(something)
end)()
if something then
  _ = 03589
else
  _ = 3434
end
if something then
  _ = yeah
elseif "ymmm" then
  print("cool")
else
  _ = okay
end
x = notsomething
y = ifsomething
local z = x and b
z = x(andb)
while 10 > something({
  something = "world"
}) do
  print("yeah")
end
x = {
  okay = sure
}
yeah({
  okay = man,
  sure = sir
})
hello("no comma", {
  yeah = dada,
  another = world
})
hello("comma", {
  something = hello_world,
  frick = you
})
another(hello, one, two, three, four, {
  yeah = man
}, {
  okay = yeah
})
a = a + (3 - 5)
a = a * (3 + 5)
a = a * 3
a = a >> 3
a = a << 3
a = a / func("cool")
x["then"] = "hello"
x["while"]["true"] = "hello"
x = x or "hello"
x = x and "hello"
z = a - b
z = a(-b)
z = a - b
z = a - b