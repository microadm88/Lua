local _exp_0 = value
if "cool" == _exp_0 then
  print("hello world")
end
local _exp_1 = value
if "cool" == _exp_1 then
  print("hello world")
else
  print("okay rad")
end
local _exp_2 = value
if "cool" == _exp_2 then
  print("hello world")
elseif "yeah" == _exp_2 then
  local _ = [[FFFF]] + [[MMMM]]
elseif (2323 + 32434) == _exp_2 then
  print("okay")
else
  print("okay rad")
end
local out
local _exp_3 = value
if "cool" == _exp_3 then
  out = print("hello world")
else
  out = print("okay rad")
end
local _exp_4 = value
if "cool" == _exp_4 then
  out = xxxx
elseif "umm" == _exp_4 then
  out = 34340
else
  out = error("this failed big time")
end
do
  local _with_0 = something
  local _exp_5 = _with_0:value()
  if _with_0.okay == _exp_5 then
    local _ = "world"
  else
    local _ = "yesh"
  end
end
fix(this)
call_func((function()
  local _exp_5 = something
  if 1 == _exp_5 then
    return "yes"
  else
    return "no"
  end
end)())
local _exp_5 = hi
if (hello or world) == _exp_5 then
  local _ = greene
end
local _exp_6 = hi
if "one" == _exp_6 or "two" == _exp_6 then
  print("cool")
elseif "dad" == _exp_6 then
  local _ = no
end
local _exp_7 = hi
if (3 + 1) == _exp_7 or hello() == _exp_7 or (function()
  return 4
end)() == _exp_7 then
  return yello
else
  return print("cool")
end