local x = {
  hello,
  (one),
  (two),
  three()
}