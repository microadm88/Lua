local house = {}

house.verse = function(which)

end

house.recite = function()

end

return house
