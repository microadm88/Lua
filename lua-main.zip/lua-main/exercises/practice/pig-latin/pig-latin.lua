return function(phrase)

end
