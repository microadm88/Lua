return function(s)

end
