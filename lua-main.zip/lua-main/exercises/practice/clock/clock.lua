local Clock = {}

return Clock
