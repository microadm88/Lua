local BinarySearchTree = {}

return BinarySearchTree
