local function normalized_plaintext(plaintext)

end

local function size(plaintext)

end

local function segments(plaintext)

end

local function normalized_ciphertext(plaintext)

end

local function ciphertext(plaintext)

end

return {
  normalized_plaintext = normalized_plaintext,
  size = size,
  segments = segments,
  ciphertext = ciphertext,
  normalized_ciphertext = normalized_ciphertext
}
