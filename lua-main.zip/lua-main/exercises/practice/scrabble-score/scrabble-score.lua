local function score(word)

end

return { score = score }
