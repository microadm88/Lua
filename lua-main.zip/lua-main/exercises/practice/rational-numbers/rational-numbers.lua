local function reduce(a)

end

local function add(a, b)

end

local function subtract(a, b)

end

local function multiply(a, b)

end

local function divide(a, b)

end

local function abs(a)

end

local function exp_rational(a, p)

end

local function exp_real(p, a)

end

return {
  add = add,
  subtract = subtract,
  multiply = multiply,
  divide = divide,
  abs = abs,
  exp_rational = exp_rational,
  exp_real = exp_real,
  reduce = reduce
}
