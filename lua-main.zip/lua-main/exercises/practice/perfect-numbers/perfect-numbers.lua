local function aliquot_sum(n)

end

local function classify(n)

end

return {
  aliquot_sum = aliquot_sum,
  classify = classify
}
