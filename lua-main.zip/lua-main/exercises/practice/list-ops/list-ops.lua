local function reduce(xs, value, f)

end

local function map(xs, f)

end

local function filter(xs, pred)

end

return {
  map = map,
  reduce = reduce,
  filter = filter
}
