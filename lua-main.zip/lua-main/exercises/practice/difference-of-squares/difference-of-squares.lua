local function square_of_sum(n)

end

local function sum_of_squares(n)

end

local function difference_of_squares(n)

end

return {
  square_of_sum = square_of_sum,
  sum_of_squares = sum_of_squares,
  difference_of_squares = difference_of_squares
}
