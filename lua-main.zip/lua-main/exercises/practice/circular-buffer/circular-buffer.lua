local CircularBuffer = {}

return CircularBuffer
