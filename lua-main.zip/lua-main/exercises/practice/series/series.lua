return function(s, length)

end
