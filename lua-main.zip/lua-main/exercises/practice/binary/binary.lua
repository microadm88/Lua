local function to_decimal(input)

end

return {
  to_decimal = to_decimal
}
