local beer = {}

function beer.verse(number)

end

function beer.sing(start, finish)

end

return beer
