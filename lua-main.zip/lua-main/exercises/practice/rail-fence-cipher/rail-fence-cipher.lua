local function encode(plaintext, rail_count)

end

local function decode(ciphertext, rail_count)

end

return { encode = encode, decode = decode }
