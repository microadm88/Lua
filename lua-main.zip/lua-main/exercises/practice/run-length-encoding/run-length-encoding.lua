return {
  encode = function(s)

  end,

  decode = function(s)

  end
}
