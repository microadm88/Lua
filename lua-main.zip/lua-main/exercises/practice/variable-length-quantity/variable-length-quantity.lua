local function decode(bytes)

end

local function encode(values)

end

return { decode = decode, encode = encode }
