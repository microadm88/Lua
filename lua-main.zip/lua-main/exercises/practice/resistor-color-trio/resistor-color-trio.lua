return {
  decode = function(c1, c2, c3)

  end
}
