return function(pos)

end
