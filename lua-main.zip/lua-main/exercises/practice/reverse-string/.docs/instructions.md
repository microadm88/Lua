# Instructions

Reverse a string

For example:
input: "cool"
output: "looc"
