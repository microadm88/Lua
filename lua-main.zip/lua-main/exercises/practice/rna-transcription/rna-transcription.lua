return function(dna)

end
