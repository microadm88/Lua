local function list(score)

end

local function allergic_to(score, which)

end

return {
  list = list,
  allergic_to = allergic_to
}
