local function flatten(input)

end

return flatten
