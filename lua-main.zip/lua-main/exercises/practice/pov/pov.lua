local function pov_from(node_name)

end

local function path_from(source)

end

return {
  pov_from = pov_from,
  path_from = path_from
}
