return {
  encode = function(plaintext)

  end
}
