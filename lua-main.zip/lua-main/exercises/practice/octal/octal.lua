return function(s)
  return {
    to_decimal = function()

    end
  }
end
