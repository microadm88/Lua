local DNA = {}

return DNA
