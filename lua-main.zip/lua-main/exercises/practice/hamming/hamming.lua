local Hamming = {}

function Hamming.compute(a,b)

end

return Hamming
