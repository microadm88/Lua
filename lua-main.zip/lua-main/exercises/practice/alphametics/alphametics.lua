local function solve(puzzle)

end

return {
  solve = solve
}
