local School = {}

return School
