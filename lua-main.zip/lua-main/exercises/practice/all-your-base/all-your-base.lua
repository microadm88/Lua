local all_your_base = {}

all_your_base.convert = function(from_digits, from_base)

end

return all_your_base
