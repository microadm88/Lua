return function(array, target)

end
