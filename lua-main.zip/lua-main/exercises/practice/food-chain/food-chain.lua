local function verse(which)

end

local function verses(from, to)

end

local function sing()

end

return {
  verse = verse,
  verses = verses,
  sing = sing
}
