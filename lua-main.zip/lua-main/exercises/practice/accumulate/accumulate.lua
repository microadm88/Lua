return function(xs, f)

end
