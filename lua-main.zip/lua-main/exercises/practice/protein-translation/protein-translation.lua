local function translate_codon(codon)

end

local function translate_rna_strand(rna_strand)

end

return {
  codon = translate_codon,
  rna_strand = translate_rna_strand
}
