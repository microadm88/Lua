local gigasecond = {}

function gigasecond.anniversary(any_date)

end

return gigasecond
