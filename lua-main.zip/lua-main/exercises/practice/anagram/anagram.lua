local Anagram = {}

return Anagram
