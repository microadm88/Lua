local grains = {}

function grains.square(n)

end

function grains.total()

end

return grains
