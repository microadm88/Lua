local function transform(board)

end

return {
  transform = transform
}
