local triangle = {}

function triangle.kind(a, b, c)

end

return triangle
