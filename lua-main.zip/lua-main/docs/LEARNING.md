Lua is a very small language and you can [learn the basics of the language in 15 minutes][1]. For an exhaustive look at the language, written by the authors of Lua, you can read [Programming in Lua][2] (the first edition which covers Lua 5.1 [is available online for free][3]).

[1]: http://tylerneylon.com/a/learn-lua/
[2]: http://www.lua.org/pil/
[3]: https://www.lua.org/pil/contents.html
