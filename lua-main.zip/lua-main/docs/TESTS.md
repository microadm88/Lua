Run your tests with

    $ busted
