-- LAT = Lua Assembly Tools
package.path = "./?/init.lua;./src/?.lua;" .. package.path
require'src'
